const products = [
  { id: 1, name: "Camiseta", price: 20, image: "https://via.placeholder.com/150" },
  { id: 2, name: "Pantalón", price: 35, image: "https://via.placeholder.com/150" },
  { id: 3, name: "Zapatos", price: 50, image: "https://via.placeholder.com/150" },
  { id: 4, name: "Gorra", price: 15, image: "https://via.placeholder.com/150" }
];

const productContainer = document.getElementById("products");
const cartItemsContainer = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");
const cartCount = document.getElementById("cart-count");
const clearCartBtn = document.getElementById("clear-cart");

let cart = [];

// Renderizar productos
products.forEach(product => {
  const div = document.createElement("div");
  div.classList.add("product");
  div.innerHTML = `
    <img src="${product.image}" alt="${product.name}">
    <h3>${product.name}</h3>
    <p>$${product.price}</p>
    <button onclick="addToCart(${product.id})">Agregar al carrito</button>
  `;
  productContainer.appendChild(div);
});

// Agregar al carrito
function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  updateCart();
}

// Actualizar carrito
function updateCart() {
  cartItemsContainer.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;
    const li = document.createElement("li");
    li.innerHTML = `${item.name} - $${item.price} 
      <button onclick="removeFromCart(${index})">❌</button>`;
    cartItemsContainer.appendChild(li);
  });

  cartTotal.textContent = "Total: $" + total;
  cartCount.textContent = cart.length;
}

// Eliminar producto del carrito
function removeFromCart(index) {
  cart.splice(index, 1);
  updateCart();
}

// Vaciar carrito
clearCartBtn.addEventListener("click", () => {
  cart = [];
  updateCart();
});
