import React, { useEffect, useState } from 'react'
const API = import.meta.env.VITE_API_URL || 'http://localhost:4242'

export default function App() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetch(`${API}/products`).then(r => r.json()).then(setProducts).catch(console.error)
  }, [])

  useEffect(() => {
    if (window.location.pathname === '/success') {
      const params = new URLSearchParams(window.location.search)
      const session_id = params.get('session_id')
      if (session_id) {
        window.location.href = `${API}/download?session_id=${session_id}`
      }
    }
  }, [])

  async function buy(productId) {
    try {
      const res = await fetch(`${API}/create-checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId })
      })
      const data = await res.json()
      if (data.url) window.location.href = data.url
      else alert('Error al crear la sesión')
    } catch (err) {
      console.error(err)
      alert('Error de red')
    }
  }

  return (
    <div style={{ maxWidth: 900, margin: 'auto', padding: 20 }}>
      <h1>Tienda digital</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: 20 }}>
        {products.map(p => (
          <div key={p.id} style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8 }}>
            <img src={p.image} alt={p.name} style={{ width: '100%', height: 140, objectFit: 'cover', borderRadius: 6 }} />
            <h3>{p.name}</h3>
            <p>{p.description}</p>
            <strong>{(p.price_cents / 100).toFixed(2)} {p.currency.toUpperCase()}</strong>
            <div style={{ marginTop: 10 }}>
              <button onClick={() => buy(p.id)}>Comprar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
