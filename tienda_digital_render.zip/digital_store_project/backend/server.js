// server.js
require('dotenv').config();
const express = require('express');
const Stripe = require('stripe');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_xxx');
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

app.use(cors({ origin: FRONTEND_URL }));
app.use(express.json());

const products = [
  {
    id: 'plantilla_insta_pro',
    name: 'Plantilla Insta Pro',
    description: 'Pack de 20 plantillas editables (Canva).',
    price_cents: 10000,
    currency: 'usd',
    image: 'https://via.placeholder.com/300x200.png?text=Plantilla+Insta+Pro',
    file: 'plantilla_insta_pro.zip'
  },
  {
    id: 'guia_marketing',
    name: 'Guía de Marketing 2025',
    description: 'PDF con estrategias rápidas.',
    price_cents: 5000,
    currency: 'usd',
    image: 'https://via.placeholder.com/300x200.png?text=Guia+Marketing',
    file: 'guia_marketing.pdf'
  }
];

app.get('/products', (req, res) => res.json(products));

app.post('/create-checkout-session', async (req, res) => {
  const { productId } = req.body;
  const product = products.find(p => p.id === productId);
  if(!product) return res.status(400).json({ error: 'Producto no encontrado' });

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: product.currency,
            product_data: {
              name: product.name,
              description: product.description,
              images: [product.image]
            },
            unit_amount: product.price_cents
          },
          quantity: 1
        }
      ],
      mode: 'payment',
      metadata: { productId: product.id },
      success_url: `${FRONTEND_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${FRONTEND_URL}/cancel`
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error creando sesión' });
  }
});

app.get('/download', async (req, res) => {
  const sessionId = req.query.session_id;
  if(!sessionId) return res.status(400).send('session_id requerido');
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if(session.payment_status !== 'paid') return res.status(403).send('Pago no confirmado');
    const productId = session.metadata.productId;
    const product = products.find(p => p.id === productId);
    if(!product) return res.status(404).send('Producto no encontrado');

    const filePath = path.join(__dirname, 'files', product.file);
    if(!fs.existsSync(filePath)) return res.status(404).send('Archivo no encontrado en el servidor');
    res.download(filePath, product.file);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error verificando pago');
  }
});

app.post('/webhook', bodyParser.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.log('Webhook signature error', err.message);
    return res.status(400).send(`Webhook error: ${err.message}`);
  }
  if(event.type === 'checkout.session.completed') {
    const session = event.data.object;
    console.log('Pago completado para session', session.id);
  }
  res.json({ received: true });
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
