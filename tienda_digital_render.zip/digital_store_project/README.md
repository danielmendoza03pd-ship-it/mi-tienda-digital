# Tienda digital - Proyecto listo

Instrucciones rápidas:

## Backend
- Ir a `backend/`
- `npm install`
- Rellenar `.env` con tus claves de Stripe (usar testing para pruebas)
- Colocar archivos en `backend/files/` (ya hay 2 placeholders)
- `npm start`

## Frontend
- Ir a `frontend/`
- `npm install`
- `npm run dev`
- Abrir http://localhost:5173 y probar compra con tarjeta de prueba (4242 4242 4242 4242)

Cambios en producción:
- Configurar FRONTEND_URL en backend con la URL de tu sitio
- Usar STRIPE_WEBHOOK_SECRET y webhooks para validar pagos
- Mover archivos a S3 y usar presigned URLs para seguridad
